import{$ as e}from"./index-CI-Z9fYs.js";const l=e("DailyVerseWallpaperPlugin");export{l as default};
