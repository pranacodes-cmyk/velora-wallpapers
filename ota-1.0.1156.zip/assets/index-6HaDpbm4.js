const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BD15h9Zj.js","assets/index-CI-Z9fYs.js","assets/index-OnmEVnCd.css"])))=>i.map(i=>d[i]);
import{$ as r,_ as t}from"./index-CI-Z9fYs.js";const o=r("Share",{web:()=>t(()=>import("./web-BD15h9Zj.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
