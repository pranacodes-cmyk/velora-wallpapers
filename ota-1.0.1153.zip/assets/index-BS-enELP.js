const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dr-ITYF3.js","assets/index-9YBwefKt.js","assets/index-OnmEVnCd.css"])))=>i.map(i=>d[i]);
import{$ as r,_ as t}from"./index-9YBwefKt.js";const o=r("Share",{web:()=>t(()=>import("./web-Dr-ITYF3.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
