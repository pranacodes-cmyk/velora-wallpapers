import{$ as e}from"./index-9YBwefKt.js";const l=e("DailyVerseWallpaperPlugin");export{l as default};
