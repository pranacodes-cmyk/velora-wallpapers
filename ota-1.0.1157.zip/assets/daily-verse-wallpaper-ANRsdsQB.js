import{$ as e}from"./index-CrJF5rDz.js";const l=e("DailyVerseWallpaperPlugin");export{l as default};
