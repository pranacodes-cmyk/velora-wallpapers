import{bw as e}from"./index-CrJF5rDz.js";class i extends e{async requestReview(){throw this.unimplemented("Not implemented on web.")}}export{i as InAppReviewWeb};
