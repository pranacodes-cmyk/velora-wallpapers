const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-8ySTqHBU.js","assets/index-CrJF5rDz.js","assets/index-OnmEVnCd.css"])))=>i.map(i=>d[i]);
import{$ as r,_ as t}from"./index-CrJF5rDz.js";const o=r("Share",{web:()=>t(()=>import("./web-8ySTqHBU.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
