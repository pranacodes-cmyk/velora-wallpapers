import{bw as e}from"./index-BBv0obUl.js";class i extends e{async requestReview(){throw this.unimplemented("Not implemented on web.")}}export{i as InAppReviewWeb};
