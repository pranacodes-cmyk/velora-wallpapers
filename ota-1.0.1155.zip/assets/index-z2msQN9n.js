const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-D-kqtEp-.js","assets/index-BBv0obUl.js","assets/index-OnmEVnCd.css"])))=>i.map(i=>d[i]);
import{$ as r,_ as t}from"./index-BBv0obUl.js";const o=r("Share",{web:()=>t(()=>import("./web-D-kqtEp-.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
