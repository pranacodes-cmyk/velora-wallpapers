import{$ as e}from"./index-BBv0obUl.js";const l=e("DailyVerseWallpaperPlugin");export{l as default};
