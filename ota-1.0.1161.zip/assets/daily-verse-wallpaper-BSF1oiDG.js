import{r as e}from"./vendor-capacitor-CCA-9kvD.js";const a=e("DailyVerseWallpaperPlugin");export{a as default};
