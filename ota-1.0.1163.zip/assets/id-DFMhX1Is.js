const a={"dev.nav.back":"Kembali","dev.toast.unlocking":"Membuka doamu…","dev.toast.unlocked":"Doa terungkap 🙏","dev.toast.stayToEnd":"Tetaplah di sini sampai akhir untuk melihat doa ini","dev.toast.error":"Tidak dapat membuka sekarang — coba lagi sebentar lagi","dev.locked.eveningLabel":"Doa Malam","dev.locked.nextLabel":"Doa Berikutnya","dev.locked.eveningTitle":"Doa Malam Hari Ini","dev.locked.tomorrowTitle":"Doa Pagi Besok","dev.locked.eveningSubtitle":"Buka sekarang, atau tunggu lonceng jam 6 sore 🌙","dev.locked.tomorrowSubtitle":"Buka sekarang, atau istirahatlah — doa ini hadir bersama matahari terbit 🌅","dev.locked.countdownLabel":"Terbuka gratis dalam","dev.locked.ctaReveal":"Ketuk untuk Membuka Lebih Awal","dev.locked.ctaWaitHint":"Atau tunggu — akan terbuka gratis segera 🙏","dev.locked.h":"Jam","dev.locked.m":"Menit","dev.locked.s":"Detik","dev.slide.continue":"Lanjutkan","dev.slide.amen":"Amin","dev.slide.prayForSomeone":"Doakan seseorang","dev.slide.swipeHint":"↑ Geser untuk doa berikutnya","dev.slide.share.title":"Doa Harian","dev.slide.share.dialog":"Bagikan doa ini","dev.slide.share.text1":`✝️ Doa Hari Ini ✝️

{{prayer}}

🙏 Amin

━━━━━━━━━━━━━
✨ Dapatkan doa harian & wallpaper Yesus yang indah!
Unduh Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ Sebuah Doa Untukmu 🕊️

{{prayer}}

🙏 Amin

━━━━━━━━━━━━━
🌟 Doa-doa indah & wallpaper Yesus HD setiap hari!
Unduh sekarang 👇
{{link}}`,"dev.slide.share.text3":`📖 Doa Harian 📖

{{prayer}}

🙏 Amin

━━━━━━━━━━━━━
✝️ Ubah ponselmu dengan iman! Dapatkan Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Tuhan mendengar doamu 🙏","dev.amen.msg2":"Imanmu memindahkan gunung ⛰️","dev.amen.msg3":"Surga bersukacita bersamamu ✨","dev.amen.msg4":"Kamu diberkati dan dicintai 💛","dev.amen.msg5":"Kasih karunia mengelilingimu hari ini 🕊️","dev.amen.msg6":"Tuhan selalu bersamamu 🌟"};export{a as default};
