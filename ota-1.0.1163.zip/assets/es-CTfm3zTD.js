const e={"dev.nav.back":"Atrás","dev.toast.unlocking":"Abriendo tu oración…","dev.toast.unlocked":"Oración revelada 🙏","dev.toast.stayToEnd":"Quédate hasta el final para revelar esta oración","dev.toast.error":"No se pudo abrir ahora; inténtalo de nuevo en un momento","dev.locked.eveningLabel":"Oración de la noche","dev.locked.nextLabel":"Próxima oración","dev.locked.eveningTitle":"Oración de la noche de hoy","dev.locked.tomorrowTitle":"Oración de la mañana de mañana","dev.locked.eveningSubtitle":"Ábrela ahora o espera a las campanas de las 6 PM 🌙","dev.locked.tomorrowSubtitle":"Ábrela ahora o descansa; llega con el amanecer 🌅","dev.locked.countdownLabel":"Se desbloquea gratis en","dev.locked.ctaReveal":"Toca para revelar antes","dev.locked.ctaWaitHint":"O espera: se desbloqueará pronto gratis 🙏","dev.locked.h":"Horas","dev.locked.m":"Min","dev.locked.s":"Seg","dev.slide.continue":"Continuar","dev.slide.amen":"Amén","dev.slide.prayForSomeone":"Orar por alguien","dev.slide.swipeHint":"↑ Desliza para la siguiente oración","dev.slide.share.title":"Oración Diaria","dev.slide.share.dialog":"Compartir esta oración","dev.slide.share.text1":`✝️ Oración de Hoy ✝️

{{prayer}}

🙏 Amén

━━━━━━━━━━━━━
✨ ¡Recibe oraciones diarias y hermosos fondos de pantalla de Jesús!
Descarga Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ Una Oración Para Ti 🕊️

{{prayer}}

🙏 Amén

━━━━━━━━━━━━━
🌟 ¡Oraciones hermosas y fondos de Jesús en HD cada día!
Descárgala ahora 👇
{{link}}`,"dev.slide.share.text3":`📖 Oración Diaria 📖

{{prayer}}

🙏 Amén

━━━━━━━━━━━━━
✝️ ¡Transforma tu celular con fe! Obtén Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Dios escucha tu oración 🙏","dev.amen.msg2":"Tu fe mueve montañas ⛰️","dev.amen.msg3":"El cielo se regocija contigo ✨","dev.amen.msg4":"Eres bendecido y amado 💛","dev.amen.msg5":"La gracia te rodea hoy 🕊️","dev.amen.msg6":"El Señor está contigo siempre 🌟"};export{e as default};
