const e={"dev.nav.back":"Zurück","dev.toast.unlocking":"Dein Gebet wird geöffnet…","dev.toast.unlocked":"Gebet enthüllt 🙏","dev.toast.stayToEnd":"Bleib bis zum Ende, um dieses Gebet zu enthüllen","dev.toast.error":"Konnte gerade nicht öffnen – versuch es bitte gleich noch einmal","dev.locked.eveningLabel":"Abendgebet","dev.locked.nextLabel":"Nächstes Gebet","dev.locked.eveningTitle":"Heutiges Abendgebet","dev.locked.tomorrowTitle":"Morgiges Morgengebet","dev.locked.eveningSubtitle":"Jetzt öffnen oder auf die Glocken um 18 Uhr warten 🌙","dev.locked.tomorrowSubtitle":"Jetzt öffnen oder ruhen – es kommt mit dem Sonnenaufgang 🌅","dev.locked.countdownLabel":"Frei in","dev.locked.ctaReveal":"Jetzt aufdecken","dev.locked.ctaWaitHint":"Oder warte – es wird bald kostenlos freigeschaltet 🙏","dev.locked.h":"Std","dev.locked.m":"Min","dev.locked.s":"Sek","dev.slide.continue":"Weiter","dev.slide.amen":"Amen","dev.slide.prayForSomeone":"Für jemanden beten","dev.slide.swipeHint":"↑ Wischen für das nächste Gebet","dev.slide.share.title":"Tägliches Gebet","dev.slide.share.dialog":"Dieses Gebet teilen","dev.slide.share.text1":`✝️ Heutiges Gebet ✝️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✨ Erhalte tägliche Gebete & wunderschöne Jesus-Hintergrundbilder!
Lade Prayly: Bible Prayer & Verse herunter 👇
{{link}}`,"dev.slide.share.text2":`🕊️ Ein Gebet für dich 🕊️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
🌟 Wunderschöne Gebete & HD Jesus-Hintergrundbilder täglich!
Jetzt herunterladen 👇
{{link}}`,"dev.slide.share.text3":`📖 Tägliches Gebet 📖

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✝️ Verwandle dein Handy mit Glauben! Hol dir Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Gott hört dein Gebet 🙏","dev.amen.msg2":"Dein Glaube versetzt Berge ⛰️","dev.amen.msg3":"Der Himmel freut sich mit dir ✨","dev.amen.msg4":"Du bist gesegnet und geliebt 💛","dev.amen.msg5":"Gnade umgibt dich heute 🕊️","dev.amen.msg6":"Der Herr ist immer mit dir 🌟"};export{e as default};
