const e={"dev.nav.back":"पीछे","dev.toast.unlocking":"आपकी प्रार्थना खुल रही है…","dev.toast.unlocked":"प्रार्थना मिल गई 🙏","dev.toast.stayToEnd":"इस प्रार्थना को देखने के लिए अंत तक रुकें","dev.toast.error":"अभी नहीं खुल सका — थोड़ी देर में फिर कोशिश करें","dev.locked.eveningLabel":"शाम की प्रार्थना","dev.locked.nextLabel":"अगली प्रार्थना","dev.locked.eveningTitle":"आज रात की प्रार्थना","dev.locked.tomorrowTitle":"कल सुबह की प्रार्थना","dev.locked.eveningSubtitle":"अभी खोलें, या शाम 6 बजे की घंटी का इंतज़ार करें 🌙","dev.locked.tomorrowSubtitle":"अभी खोलें, या आराम करें — यह सूरज की पहली किरण के साथ आएगी 🌅","dev.locked.countdownLabel":"मुफ्त में खुलेगी","dev.locked.ctaReveal":"जल्दी देखने के लिए दबाएं","dev.locked.ctaWaitHint":"या इंतज़ार करें — यह जल्द ही मुफ्त में खुल जाएगी 🙏","dev.locked.h":"घंटे","dev.locked.m":"मिनट","dev.locked.s":"सेकंड","dev.slide.continue":"आगे बढ़ें","dev.slide.amen":"आमीन","dev.slide.prayForSomeone":"किसी के लिए प्रार्थना करें","dev.slide.swipeHint":"↑ अगली प्रार्थना के लिए ऊपर स्वाइप करें","dev.slide.share.title":"रोजाना की प्रार्थना","dev.slide.share.dialog":"इस प्रार्थना को शेयर करें","dev.slide.share.text1":`✝️ आज की प्रार्थना ✝️

{{prayer}}

🙏 आमीन

━━━━━━━━━━━━━
✨ रोजाना प्रार्थना और यीशु के सुंदर वॉलपेपर पाएं!
Prayly डाउनलोड करें: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ आपके लिए एक प्रार्थना 🕊️

{{prayer}}

🙏 आमीन

━━━━━━━━━━━━━
🌟 हर दिन सुंदर प्रार्थनाएं और यीशु के HD वॉलपेपर!
अभी डाउनलोड करें 👇
{{link}}`,"dev.slide.share.text3":`📖 रोजाना की प्रार्थना 📖

{{prayer}}

🙏 आमीन

━━━━━━━━━━━━━
✝️ अपने फोन को विश्वास से भरें! Prayly पाएं: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"ईश्वर आपकी प्रार्थना सुन रहा है 🙏","dev.amen.msg2":"आपका विश्वास पहाड़ों को भी हिला सकता है ⛰️","dev.amen.msg3":"स्वर्ग आपके साथ खुशियां मना रहा है ✨","dev.amen.msg4":"आप धन्य और प्रिय हैं 💛","dev.amen.msg5":"आज ईश्वर की कृपा आपके साथ है 🕊️","dev.amen.msg6":"प्रभु हमेशा आपके साथ हैं 🌟"};export{e as default};
