const a={"dev.nav.back":"Bumalik","dev.toast.unlocking":"Binubuksan ang iyong prayer…","dev.toast.unlocked":"Nabuksan na ang panalangin 🙏","dev.toast.stayToEnd":"Stay until the end para ma-reveal ang prayer na ito","dev.toast.error":"Hindi ma-open ngayon — subukan ulit mamaya","dev.locked.eveningLabel":"Panalangin sa Gabi","dev.locked.nextLabel":"Susunod na Panalangin","dev.locked.eveningTitle":"Panalangin para Ngayong Gabi","dev.locked.tomorrowTitle":"Panalangin sa Umaga Bukas","dev.locked.eveningSubtitle":"I-open na, o maghintay sa bells ng 6 PM 🌙","dev.locked.tomorrowSubtitle":"I-open na, o magpahinga muna — darating ito kasabay ng sunrise 🌅","dev.locked.countdownLabel":"Mag-a-unlock nang libre sa loob ng","dev.locked.ctaReveal":"Pindutin para Buksan Agad","dev.locked.ctaWaitHint":"O maghintay lang — mag-a-unlock din ito nang libre 🙏","dev.locked.h":"Oras","dev.locked.m":"Min","dev.locked.s":"Sec","dev.slide.continue":"Magpatuloy","dev.slide.amen":"Amen","dev.slide.prayForSomeone":"Ipagdasal ang iba","dev.slide.swipeHint":"↑ Swipe para sa next prayer","dev.slide.share.title":"Panalangin Araw-araw","dev.slide.share.dialog":"I-share ang prayer na ito","dev.slide.share.text1":`✝️ Today's Prayer ✝️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✨ Kumuha ng daily prayers & beautiful Jesus wallpapers!
Download Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ A Prayer For You 🕊️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
🌟 Beautiful prayers & HD Jesus wallpapers daily!
Download na 👇
{{link}}`,"dev.slide.share.text3":`📖 Daily Prayer 📖

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✝️ Transform your phone with faith! Kunin ang Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Naririnig ng Diyos ang iyong dasal 🙏","dev.amen.msg2":"Ang iyong pananampalataya ay nakakapagpagalaw ng bundok ⛰️","dev.amen.msg3":"Nagsasaya ang langit kasama mo ✨","dev.amen.msg4":"Ikaw ay pinagpala at minamahal 💛","dev.amen.msg5":"Nakapaligid sa iyo ang biyaya ngayong araw 🕊️","dev.amen.msg6":"Ang Panginoon ay laging nasa iyong tabi 🌟"};export{a as default};
