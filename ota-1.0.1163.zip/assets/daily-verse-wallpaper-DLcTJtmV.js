import{r as e}from"./vendor-capacitor-CYErwOP2.js";const a=e("DailyVerseWallpaperPlugin");export{a as default};
