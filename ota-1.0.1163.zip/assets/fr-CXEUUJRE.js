const e={"dev.nav.back":"Retour","dev.toast.unlocking":"Ouverture de ta prière…","dev.toast.unlocked":"Prière révélée 🙏","dev.toast.stayToEnd":"Reste jusqu'à la fin pour révéler cette prière","dev.toast.error":"Impossible d'ouvrir pour le moment — réessaie dans un instant","dev.locked.eveningLabel":"Prière du soir","dev.locked.nextLabel":"Prochaine prière","dev.locked.eveningTitle":"Prière du soir d'aujourd'hui","dev.locked.tomorrowTitle":"Prière du matin de demain","dev.locked.eveningSubtitle":"Ouvre-la maintenant, ou attends les cloches de 18h 🌙","dev.locked.tomorrowSubtitle":"Ouvre-la maintenant, ou repose-toi — elle arrive avec le lever du soleil 🌅","dev.locked.countdownLabel":"Déblocage gratuit dans","dev.locked.ctaReveal":"Appuie pour révéler plus tôt","dev.locked.ctaWaitHint":"Ou attends — elle sera gratuite bientôt 🙏","dev.locked.h":"Heures","dev.locked.m":"Min","dev.locked.s":"Sec","dev.slide.continue":"Continuer","dev.slide.amen":"Amen","dev.slide.prayForSomeone":"Prier pour quelqu'un","dev.slide.swipeHint":"↑ Glisse pour la prière suivante","dev.slide.share.title":"Prière Quotidienne","dev.slide.share.dialog":"Partager cette prière","dev.slide.share.text1":`✝️ Prière d'aujourd'hui ✝️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✨ Reçois des prières quotidiennes et de magnifiques fonds d'écran de Jésus !
Télécharge Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ Une prière pour toi 🕊️

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
🌟 De magnifiques prières et fonds d'écran HD de Jésus chaque jour !
Télécharge maintenant 👇
{{link}}`,"dev.slide.share.text3":`📖 Prière Quotidienne 📖

{{prayer}}

🙏 Amen

━━━━━━━━━━━━━
✝️ Transforme ton téléphone avec la foi ! Reçois Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Dieu entend ta prière 🙏","dev.amen.msg2":"Ta foi déplace les montagnes ⛰️","dev.amen.msg3":"Le ciel se réjouit avec toi ✨","dev.amen.msg4":"Tu es béni et aimé 💛","dev.amen.msg5":"La grâce t'entoure aujourd'hui 🕊️","dev.amen.msg6":"Le Seigneur est toujours avec toi 🌟"};export{e as default};
