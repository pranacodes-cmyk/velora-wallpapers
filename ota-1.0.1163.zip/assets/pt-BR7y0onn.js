const e={"dev.nav.back":"Voltar","dev.toast.unlocking":"Abrindo sua oração…","dev.toast.unlocked":"Oração revelada 🙏","dev.toast.stayToEnd":"Fique até o final para revelar esta oração","dev.toast.error":"Não foi possível abrir agora — tente novamente em instantes","dev.locked.eveningLabel":"Oração da Noite","dev.locked.nextLabel":"Próxima Oração","dev.locked.eveningTitle":"Oração da Noite de hoje","dev.locked.tomorrowTitle":"Oração da Manhã de amanhã","dev.locked.eveningSubtitle":"Abra agora ou espere os sinos às 18h 🌙","dev.locked.tomorrowSubtitle":"Abra agora ou descanse — ela chega com o nascer do sol 🌅","dev.locked.countdownLabel":"Desbloqueia gratuitamente em","dev.locked.ctaReveal":"Toque para revelar antes","dev.locked.ctaWaitHint":"Ou espere — será desbloqueada grátis em breve 🙏","dev.locked.h":"Horas","dev.locked.m":"Min","dev.locked.s":"Seg","dev.slide.continue":"Continuar","dev.slide.amen":"Amém","dev.slide.prayForSomeone":"Orar por alguém","dev.slide.swipeHint":"↑ Deslize para a próxima oração","dev.slide.share.title":"Oração Diária","dev.slide.share.dialog":"Compartilhar esta oração","dev.slide.share.text1":`✝️ Oração de Hoje ✝️

{{prayer}}

🙏 Amém

━━━━━━━━━━━━━
✨ Receba orações diárias e lindos papéis de parede de Jesus!
Baixe o Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.slide.share.text2":`🕊️ Uma Oração Para Você 🕊️

{{prayer}}

🙏 Amém

━━━━━━━━━━━━━
🌟 Lindas orações e papéis de parede de Jesus em HD todos os dias!
Baixe agora 👇
{{link}}`,"dev.slide.share.text3":`📖 Oração Diária 📖

{{prayer}}

🙏 Amém

━━━━━━━━━━━━━
✝️ Transforme seu celular com fé! Obtenha o Prayly: Bible Prayer & Verse 👇
{{link}}`,"dev.amen.msg1":"Deus ouve sua oração 🙏","dev.amen.msg2":"Sua fé move montanhas ⛰️","dev.amen.msg3":"O céu se alegra com você ✨","dev.amen.msg4":"Você é abençoado e amado 💛","dev.amen.msg5":"A graça te cerca hoje 🕊️","dev.amen.msg6":"O Senhor está com você sempre 🌟"};export{e as default};
