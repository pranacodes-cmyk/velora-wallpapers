import{a5 as e}from"./index-C0q4E_gn.js";class i extends e{async requestReview(){throw this.unimplemented("Not implemented on web.")}}export{i as InAppReviewWeb};
