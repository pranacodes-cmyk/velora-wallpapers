const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BK-KtdVE.js","assets/index-BCahqzMZ.js","assets/index-OnmEVnCd.css"])))=>i.map(i=>d[i]);
import{$ as r,_ as t}from"./index-BCahqzMZ.js";const o=r("Share",{web:()=>t(()=>import("./web-BK-KtdVE.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{o as Share};
