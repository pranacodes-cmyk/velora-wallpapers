import{$ as e}from"./index-BCahqzMZ.js";const l=e("DailyVerseWallpaperPlugin");export{l as default};
